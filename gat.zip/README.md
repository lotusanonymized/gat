# Adversarial Defense via Learning to Generate Diverse Attacks #


This repository includes the codes for ICCV 2019 paper.
* Yunseok Jang, Tianchen Zhao, Seunghoon Hong and Honglak Lee. [_Adversarial Defense via Learning to Generate Diverse Attacks_](http://openaccess.thecvf.com/content_ICCV_2019/papers/Jang_Adversarial_Defense_via_Learning_to_Generate_Diverse_Attacks_ICCV_2019_paper.pdf). In ICCV, 2019



```
@inproceedings{jang-ICCV-2019,
    author    = {Yunseok Jang and Tianchen Zhao and Seunghoon Hong and Honglak Lee},
    title     = {{Adversarial Defense via Learning to Generate Diverse Attacks}},
    booktitle = {ICCV},
    year      = 2019
}
```


## Generator Model Architecture ##
```
Input: y[10] (one-hot encoding of the labels)
Linear 1024 LeakyReLU
Concatenate with y
Linear 8192 LeakyReLU
Reshape (8, 8, 128)
Concatenate with y (reshaped)
(3, 3) Upconv 128, stride=2
Concatenate with y (reshaped)
(3, 3) Upconv 128, stride=2
Concatenate with [x, ∇x]
(3, 3) Conv 128, stride=1 LeakyReLU
(3, 3) Conv 3, stride=1
Activation: xadv = (1/2) (tanh (atanh (2x − 1) + G(∇xF, x, y; φ)) + 1)
```


## How to Use ##

### 1. Environment Setup ###
```
conda create -n l2lda -y
source activate l2lda
conda config --add channels conda-forge
conda install -c conda-forge python=3.6.4 numba -y
# conda install -c anaconda cudatoolkit=10.0 cudnn=7.6 -y
conda install pytorch=1.1.0 torchvision=0.3.0 cudatoolkit=10.0 -c pytorch -y
pip install requests gpustat tensorboardX tensorflow-gpu visdom tqdm matplotlib scikit-image

# I've forked and included this code base
# git clone https://github.com/revbucket/mister_ed.git
# Also, this repo includes edited version of Synced Batch Norm from this repository
# git clone https://github.com/vacancy/Synchronized-BatchNorm-PyTorch
```

Then, add [mister_ed](https://github.com/revbucket/mister_ed.git) package setting to conda environment.
```
conda install conda-build
cd ./mister_ed
conda develop .

# Download pretrained ResNet Classifier trained on CIFAR-10 dataset
python scripts/setup_cifar.py
mv pretrained_models/ ../
cd ..
```

### 2. Train a new classifier ###

```
CUDA_VISIBLE_DEVICES=0 python main.py --f_classifier_name='gat' --dataset=cifar10 --is_rgb=True --img_size=32 --epsilon=0.031372549 --g_optimizer=sgd --g_lr=0.01 --f_pretrain=False --g_method=3 --train_g_iter=10 --g_ministep_size=0.25 --dsgan_lambda=0.5 --g_mini_update_style=2 --f_update_style=1 --num_gpu=1
```

### 3. Measure the classification performance of a classifier ###

```
CUDA_VISIBLE_DEVICES=0 python evaluation_cifar.py --path=/path/to/directory
```
