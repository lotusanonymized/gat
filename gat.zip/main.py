import torch

from adv_defence.trainer import Trainer
from adv_defence.classifier_tester import ClassifierTester

from adv_defence.config import get_config
from adv_defence.utils import prepare_dirs_and_logger, save_config
from adv_defence.data_loader import get_loader
import numpy as np
import random

from functools import partial
from ray import tune
from ray.tune import CLIReporter
from ray.tune.schedulers import ASHAScheduler

def main(config):
    prepare_dirs_and_logger(config)

    np.random.seed(config.random_seed)
    random.seed(config.random_seed)
    torch.manual_seed(config.random_seed)
    if config.num_gpu > 0:
        torch.cuda.manual_seed(config.random_seed)

    train_data_loader = get_loader(dataset_name=config.dataset,
                                   root=config.data_path,
                                   batch_size=config.single_batch_size,
                                   split='train',
                                   num_workers=config.num_workers,
                                   shuffle=True)
    test_data_loader = get_loader(dataset_name=config.dataset,
                                  root=config.data_path,
                                  batch_size=config.single_batch_size,
                                  split='test',
                                  num_workers=config.num_workers,
                                  shuffle=False)
    
    ray_config = {
        "g_lr": tune.loguniform(1e-4, 1e-1),
        "f_lr": tune.loguniform(1e-4, 1e-1),
        "cl": tune.sample_from(lambda _: 2**np.random.randint(-8, -2)),
        "alpha": tune.sample_from(lambda _: np.random.uniform(0, 1))
    }

    if not config.is_train:
        if config.need_samples:
            toolkit = Trainer(config, None, test_data_loader)
            toolkit.get_sample_pdf_of_checkpoint()
        else:
            evaluator = ClassifierTester(config, test_data_loader)
            evaluator.test_classifier_with_l2lda_att()
            #evaluator.test_classifier_with_gat(config.epsilon)
            #evaluator.test_classifier_with_others('FGSM')
            #evaluator.test_gat_with_others('FGSM')
    else:
        trainer = Trainer(config, train_data_loader, test_data_loader)
        save_config(config)
        if config.f_classifier_name == 'gat':
            print("\n Training for GAT! \n")
            trainer.train_gat(config.epsilon/20, 0.7)
            #trainer.train_gat_with_fgsm(config.epsilon)

            #trainer.defence_regular_eval()
            #trainer.train_gat_noisegen(config.epsilon, 0.5)

            # scheduler = ASHAScheduler(
            #     metric="loss",
            #     mode="min",
            #     max_t=10,
            #     grace_period=1,
            #     reduction_factor=2)
            # reporter = CLIReporter(
            #     # parameter_columns=["l1", "l2", "lr", "batch_size"],
            #     metric_columns=["loss", "accuracy", "training_iteration"])
            # result = tune.run(
            #     partial(trainer.train_gat_with_ray,data_dir=train_data_loader),
            #     resources_per_trial={"cpu": 2, "gpu": 3},
            #     config=ray_config,
            #     num_samples=10,
            #     scheduler=scheduler,
            #     progress_reporter=reporter)

            # best_trial = result.get_best_trial("loss", "min", "last")
            # print("Best trial config: {}".format(best_trial.config))
            # print("Best trial final validation loss: {}".format(
            #     best_trial.last_result["loss"]))
            # print("Best trial final validation accuracy: {}".format(
            #     best_trial.last_result["accuracy"]))
            #trainer.gat_train_noisegen(0, 0)

        else:
            #trainer.train()
            trainer.train_with_fgsm('FGSM')
            #trainer.train_gat_noisegen(0,0)


if __name__ == "__main__":
    config, unparsed = get_config()
    main(config)
